﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Button b = (Button)sender;
            js.Text += b.Content.ToString();  //是不是相当于文本框显示按钮按下去的东西
        }

        private void Result_Click_1(object sender, RoutedEventArgs e)
        {
            string temp0;
            int temp1 = 0;
            if (js.Text.Contains("+"))
            {
                temp1 = js.Text.IndexOf("+");    //所以是下标吗
            }
            else if (js.Text.Contains("-"))
            {
                temp1 = js.Text.IndexOf("-");
            }
            else if (js.Text.Contains("*"))
            {
                temp1 = js.Text.IndexOf("*");
            }
            else if (js.Text.Contains("/"))
            {
                temp1 = js.Text.IndexOf("/");
            }

            temp0 = js.Text.Substring(temp1, 1);   //所以是一个字符串吗  后面的是截取长度吗？
            double op1 = Convert.ToDouble(js.Text.Substring(0, temp1));
            double op2 = Convert.ToDouble(js.Text.Substring(temp1 + 1, js.Text.Length - temp1 - 1));

            if (temp0 == "+")
            {
                js.Text += "=" + (op1 + op2);
            }
            if (temp0 == "-")
            {
                js.Text += "=" + (op1 - op2);
            }
            if (temp0 == "*")
            {
                js.Text += "=" + (op1 * op2);
            }
            if (temp0 == "/")
            {
                js.Text += "=" + (op1 / op2);
            }
        }

        private void R_Click_1(object sender, RoutedEventArgs e)
        {
            js.Text = "";
        }

        private void Del_Click_del(object sender, RoutedEventArgs e)
        {
            if (js.Text.Length > 0)
            {
                js.Text = js.Text.Substring(0, js.Text.Length - 1);
            }
        }

        private void Off_Click_1(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
