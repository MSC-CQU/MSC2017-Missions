﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DavidLee.Arithmetics
{
	public class Arithmetics
	{
		List<string> splited;
		Queue<string> parsed = new Queue<string>();

		public double Result { get; private set; } = 0;

		void MultiExtract()
		{
			for (int i = 0; i < splited.Count - 1; i++)
			{
				if (splited[i] == "*" || splited[i] == "/")
				{
					Queue<string> subEquation = new Queue<string>();
					//string subString = "";
					subEquation.Enqueue(splited[i - 2] + splited[i - 1]);
					//subString += splited[i - 1];
					splited[i - 2] = "";
					splited[i - 1] = "";
					Continue(ref i, ref subEquation);
					Multiplication tmp = new Multiplication(subEquation);
					splited[i - 2] = "+";
					splited[i - 1] = tmp.Evaluate().ToString();
				}
			}
			splited.RemoveAll(x => x == "");
			void Continue(ref int index, ref Queue<string> str)
			{
				do
				{
					str.Enqueue(splited[index]);
					splited[index] = "";
					str.Enqueue(splited[index + 1]);
					splited[index + 1] = "";
					index += 2;
				}
				while (index < splited.Count && (splited[index] == "*" || splited[index] == "/"));
			}

		}
		void ParenthesisEx()
		{
			int leftCount = 0;
			int startIndex = 0;
			int endIndex = 0;
			for (int i = 0; i < splited.Count; i++)
			{
				if(splited[i] == "(")
				{
					if(leftCount == 0)
					{
						startIndex = i;
					}
					leftCount++;
				}
				if(splited[i] == ")")
				{
					leftCount--;
					if(leftCount == 0)
					{
						endIndex = i;
						string[] str = new string[endIndex - startIndex - 1];
						for (int j = startIndex + 1; j < endIndex; j++)
						{
							str[j - startIndex - 1] = splited[j];
						}
						Arithmetics tmp = new Arithmetics(str);
						//Result += tmp.Evaluate();
						for (int j = startIndex; j < endIndex + 1; j++)
						{
							splited[j] = "";
						}
						splited[startIndex] = tmp.Evaluate().ToString();
					}
				}
			}
			splited.RemoveAll(x => x == "");
		}
		void FunctionEval()
		{
			//	// x^y, log, ln, sin, cos, tan, sqrt
			for (int i = 0; i < splited.Count; i++)
			{
				// TODO: Remove processed chars! 
				if(splited[i].Contains("^"))
				{
					splited[i] = Math.Pow(double.Parse(splited[i - 1]), double.Parse(splited[i + 1])).ToString();
					splited[i - 1] = ""; splited[i + 1] = "";
				}
				else if (splited[i].StartsWith("sqrt"))
				{
					splited[i] = Math.Sqrt(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
				else if (splited[i].StartsWith("log"))
				{
					splited[i] = Math.Log10(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
				else if(splited[i].StartsWith("ln"))
				{
					splited[i] = Math.Log(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
				else if (splited[i].StartsWith("sin"))
				{
					splited[i] = Math.Sin(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
				else if (splited[i].StartsWith("cos"))
				{
					splited[i] = Math.Cos(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
				else if(splited[i].StartsWith("tan"))
				{
					splited[i] = Math.Tan(double.Parse(splited[i + 1])).ToString();
					splited[i + 1] = "";
				}
			}
			splited.RemoveAll(x => x == "");
		}

		public double Evaluate()
		{
			for (int i = 0; i < splited.Count; i++)
			{
				if(splited[i] == "+")
				{
					Result += double.Parse(splited[i + 1]);
					i++;
				}
				else if(splited[i] == "-")
				{
					Result -= double.Parse(splited[i + 1]);
					i++;
				}
				else { throw new ArgumentException("High-priority operations not cleared. "); }
			}
			return Result;
		}

		public Arithmetics(string input)
		{
			//Input = input.TrimEnd();
			if (input.Length > 0)
			{
				if (input[0] != '+' && input[0] != '-')
				{
					input = "+ " + input;
				}
				splited = input.Split(new char[] { ' ' }).ToList<string>();

			}
			else
			{
				splited = new List<string>(2);
				splited.Add("+"); splited.Add("0");
			}
			splited.RemoveAll(x => x == " ");
			ParenthesisEx();
			FunctionEval();
			MultiExtract();
		}
		public Arithmetics(string[] input)
		{
			if (input.Length > 0)
			{
				splited = new List<string>(input.Length + 1);
				splited.Add("+");
				for (int i = 0; i < input.Length; i++)
				{
					splited.Add(input[i]);
				}

			}
			else
			{
				splited = new List<string>(2);
				splited.Add("+"); splited.Add("0");
			}
			ParenthesisEx();
			FunctionEval();
			MultiExtract();
		}

		class Multiplication
		{
			Queue<string> input;
			double result;
			
			public double Evaluate()
			{
				result = double.Parse(input.Dequeue());
				while(input.Count > 0)
				{
					switch(input.Dequeue())
					{
						case "*":
							result *= double.Parse(input.Dequeue());
							break;
						case "/":
							result /= double.Parse(input.Dequeue());
							break;
						default:
							throw new ArgumentException("Multiplication subequation has invalid operators. ");
					}
				}
				return result;
			}
			public Multiplication(Queue<string> str)
			{
				input = str;
			}
		}
	}
}
