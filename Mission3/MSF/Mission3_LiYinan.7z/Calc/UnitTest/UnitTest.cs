﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DavidLee.Arithmetics;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestParse()
        {
			Arithmetics testArith = new Arithmetics("1 + 2 * 3 / 4 - ( 5 - 6 ) + log ( 10 ^ 2 )");
			Assert.AreEqual(1 + 2 * 3 / 4.0 + 1 + Math.Log10(100), testArith.Evaluate());
        }
		[TestMethod]
		public void TestParse2()
		{
			Arithmetics testAr = new Arithmetics("( 1 + 2 * ( 2 - 3 ) )");
			Assert.AreEqual(1 + 2 * -1, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse3()
		{
			Arithmetics testAr = new Arithmetics("sin ( 1 * ( 2 + 5 ) )");
			Assert.AreEqual(Math.Round(Math.Sin(7),7), Math.Round(testAr.Evaluate(),7));
		}
		[TestMethod]
		public void TestParse4()
		{
			Arithmetics testAr = new Arithmetics("( 2 + 2 ) ^ ( log ( 100 * 100 ) )");
			Assert.AreEqual(256, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse5()
		{
			Arithmetics testAr = new Arithmetics("- sqrt ( 2 + 2 )");
			Assert.AreEqual(-2, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse6()
		{
			Arithmetics testAr = new Arithmetics("5");
			Assert.AreEqual(5, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse7()
		{
			Arithmetics testAr = new Arithmetics(".3");
			Assert.AreEqual(0.3, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse8()
		{
			Arithmetics testAr = new Arithmetics("sqrt 4");
			Assert.AreEqual(2, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse9()
		{
			Arithmetics testAr = new Arithmetics("");
			Assert.AreEqual(0, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse10()
		{
			Arithmetics testAr = new Arithmetics("sqrt ( )");
			Assert.AreEqual(0, testAr.Evaluate());
		}
		[TestMethod]
		public void TestParse11()
		{
			Arithmetics testAr = new Arithmetics("sqrt ( log 10000 )");
			Assert.AreEqual(2, testAr.Evaluate());
		}

	}
}
