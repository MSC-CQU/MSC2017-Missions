﻿//#define dotDebug

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using DavidLee.Complex;
using Windows.ApplicationModel.Resources;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Calc
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Cmplx : Page
    {
        public Cmplx()
        {
            this.InitializeComponent();
			FirstRun();
        }

		Complex lhs = new Complex();
		Complex rhs = new Complex();

		bool dotted = false;

		OpCode prevOp = OpCode.Add;

		string lhsStr = "";
		string rhsStr = "";

		bool isEnteringI = false;
		ResourceLoader resLoader = ResourceLoader.GetForCurrentView();

		private void BtnClear_Click(object sender, RoutedEventArgs e)
		{
			ClearCalc();
		}

		private void ClearCalc()
		{
			lhs = new Complex(0, 0);
			rhs = new Complex(0, 0);
			isEnteringI = false;
			lhsStr = "";
			rhsStr = "0";
			LhsBox.Text = lhsStr;
			RhsBox.Text = rhsStr;
			prevOp = OpCode.Add;
			DottedEvaluate();
			CopyStore.DisplayStr = RhsBox.Text;
		}

		void FirstRun()
		{
			Btn1.Click += NumPadBtn_Click;
			Btn2.Click += NumPadBtn_Click;
			Btn3.Click += NumPadBtn_Click;
			Btn4.Click += NumPadBtn_Click;
			Btn5.Click += NumPadBtn_Click;
			Btn6.Click += NumPadBtn_Click;
			Btn7.Click += NumPadBtn_Click;
			Btn8.Click += NumPadBtn_Click;
			Btn9.Click += NumPadBtn_Click;
			Btn0.Click += NumPadBtn_Click;
			BtnDot.Click += NumPadBtn_Click;
			BtnI.Click += NumPadBtn_Click;

			BtnPlus.Click += FunctionBtn_Click;
			BtnSubtract.Click += FunctionBtn_Click;
			BtnMulti.Click += FunctionBtn_Click;
			BtnDiv.Click += FunctionBtn_Click;
		}
		private void NumPadBtn_Click(object sender, RoutedEventArgs e)
		{
			if(prevOp == OpCode.Undefined) { ClearCalc(); }
			if(rhsStr == "0") { rhsStr = ""; }
			if (rhsStr.Length == 0 || (rhsStr.Length > 0 && rhsStr.Last() != 'i'))
			{
				if ((sender as Button).Content.ToString() == "i")
				{
					rhsStr += "i";
					isEnteringI = true;
				}
				else if((sender as Button).Content.ToString() == ".")
				{
					if (!dotted) { rhsStr += "."; dotted = true; }
				}
				else
				{
					rhsStr += (sender as Button).Content.ToString();
				}
			}
			LhsBox.Text = lhsStr;
			RhsBox.Text = rhsStr;
			DottedEvaluate();
			CopyStore.DisplayStr = RhsBox.Text;
		}
		private void FunctionBtn_Click(object sender, RoutedEventArgs e)
		{
			if (isEnteringI == true)
			{
				PerformCalc();
				switch ((sender as Button).Name)
				{
					case "BtnPlus":
						prevOp = OpCode.Add;
						break;
					case "BtnSubtract":
						prevOp = OpCode.Subtract;
						break;
					case "BtnMulti":
						prevOp = OpCode.Multiply;
						break;
					case "BtnDiv":
						prevOp = OpCode.Divide;
						break;
					default:
						throw new ArgumentException();
				}
			}
			else
			{
				switch ((sender as Button).Name)
				{
					case "BtnPlus":
						isEnteringI = true;
						rhsStr += " + ";
						break;
					case "BtnSubtract":
						isEnteringI = true;
						rhsStr += " - ";
						break;
					case "BtnMulti":
						PerformCalc();
						prevOp = OpCode.Multiply;
						break;
					case "BtnDiv":
						PerformCalc();
						prevOp = OpCode.Divide;
						break;
					default:
						throw new ArgumentException();
				}
			}
			DottedEvaluate();
			LhsBox.Text = lhsStr;
			RhsBox.Text = rhsStr;
			CopyStore.DisplayStr = RhsBox.Text;
		}

		private void PerformCalc()
		{
			switch (prevOp)
			{
				case OpCode.Add:
					lhs += ParseStr(rhsStr);
					lhsStr = lhs.ToString();
					isEnteringI = false;
					break;
				case OpCode.Subtract:
					lhs -= ParseStr(rhsStr);
					lhsStr = lhs.ToString();
					isEnteringI = false;
					break;
				case OpCode.Multiply:
					lhs *= ParseStr(rhsStr);
					lhsStr = lhs.ToString();
					isEnteringI = false;
					break;
				case OpCode.Divide:
					lhs /= ParseStr(rhsStr);
					lhsStr = lhs.ToString();
					isEnteringI = false;
					break;
				case OpCode.Undefined:
					lhs = new Complex();
					lhs += rhs;
					lhsStr = lhs.ToString();
					isEnteringI = false;
					break;
			}
			rhs = new Complex();
			rhsStr = rhs.ToString();
			lhsStr = lhs.ToString();
		}

		private void BtnCE_Click(object sender, RoutedEventArgs e)
		{
			rhs = new Complex(0, 0);
			rhsStr = "0";
			LhsBox.Text = lhsStr;
			RhsBox.Text = rhsStr;
			dotted = false;
			CopyStore.DisplayStr = RhsBox.Text;
		}

		enum OpCode
		{
			Add, Subtract, Multiply, Divide, Undefined
		}

		Complex ParseStr(string str)
		{
			if(str == "") { return new Complex(); }
			string[] strs;
			if (str.Contains("+"))
			{
				strs = str.Split('+');
				double real = double.Parse(strs[0].Trim());
				string imagStr = strs[1].Trim();
				if(imagStr.Last() == 'i')
				{
					imagStr = imagStr.Remove(imagStr.Length - 1);
					if (imagStr == "") { imagStr = "1"; }
					double imag = double.Parse(imagStr);
					return new Complex(real, imag);
				}
				else
				{
					if (imagStr == "") { imagStr = "1"; }
					double imag = double.Parse(imagStr);
					return new Complex(real + imag, 0);
				}
			}
			else if (str.Contains("-"))
			{
				strs = str.Split('-');
				double real = double.Parse(strs[0].Trim());
				string imagStr = strs[1].Trim();
				if (imagStr.Last() == 'i')
				{
					imagStr = imagStr.Remove(imagStr.Length - 1);
					if (imagStr == "") { imagStr = "1"; }
					double imag = double.Parse(imagStr);
					return new Complex(real, imag);
				}
				else
				{
					if (imagStr == "") { imagStr = "1"; }
					double imag = double.Parse(imagStr);
					return new Complex(real - imag, 0);
				}
			}
			else if (str.Contains("i"))
			{
				string imagStr = str.Trim().Remove(str.Length - 1);
				if(imagStr.Length == 0) { imagStr = "1"; }
				double imag = double.Parse(imagStr);
				return new Complex(0, imag);
			}
			else
			{
				return new Complex(double.Parse(str.Trim()), 0);
			}
		}

		private void BtnEqu_Click(object sender, RoutedEventArgs e)
		{
			FinalizeCalc();
			LhsBox.Text = lhsStr;
			//prevOp = OpCode.Undefined;
			CopyStore.DisplayStr = RhsBox.Text;
		}

		private void FinalizeCalc()
		{
			try
			{
				PerformCalc();
				rhs = lhs;
				RhsBox.Text = rhs.ToString();
				lhsStr = "0";
				prevOp = OpCode.Undefined;
				DottedEvaluate();
			}
			catch (DivideByZeroException)
			{
				ClearCalc();
				RhsBox.Text = resLoader.GetString("DivZeroMsg");
				//displayStr = "Cannot divide by zero";
			}
			catch (ArgumentOutOfRangeException)
			{
				ClearCalc();
				RhsBox.Text = resLoader.GetString("InvalidArgsMsg");
				//displayStr = "Invalid argument";
			}
			catch (FormatException)
			{
				ClearCalc();
				RhsBox.Text = resLoader.GetString("FormatErrMsg");
				//displayStr = "Input format error";
			}
			catch (IndexOutOfRangeException)
			{
				ClearCalc();
				RhsBox.Text = resLoader.GetString("FormatErrMsg");
				//displayStr = "Input format error";
			}
			CopyStore.DisplayStr = "";
		}

		private void BtnConj_Click(object sender, RoutedEventArgs e)
		{
			FinalizeCalc();
			rhs = rhs.Conjunction();
			LhsBox.Text = lhsStr;
			rhsStr = rhs.ToString();
			RhsBox.Text = rhsStr;
			DottedEvaluate();
			CopyStore.DisplayStr = RhsBox.Text;
		}

		void DottedEvaluate()
		{
			dotted = false;
			for (int i = rhsStr.Length - 1; i >= 0; i--)
			{
				if (rhsStr[i] == '.') { dotted = true; }
				if (rhsStr[i] == ' ') { break; }
			}
#if dotDebug
			LhsBox.Text = dotted.ToString();
#endif
		}

	}
}
