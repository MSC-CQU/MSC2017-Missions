﻿//#define dotDebug
//#define parseDebug
#define disDebug

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using DavidLee.Arithmetics;
using Windows.ApplicationModel.Resources;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Calc
{
	/// <summary>
	/// An empty page that can be used on its own or navigated to within a Frame.
	/// </summary>
	public sealed partial class Real : Page
	{
		string internalStr = "";
		string displayStr = "0";
		bool dotted = false;
		ResourceLoader resLoader = ResourceLoader.GetForCurrentView();

		public Real()
		{
			this.InitializeComponent();
			FirstRun();
		}

		private void NumPadBtn_Click(object sender,RoutedEventArgs e)
		{
			if(displayStr == "0") { displayStr = ""; }
			Button clickedBtn = (Button)sender;
			if((string)clickedBtn.Content == "." && dotted == true) { return; }
			//displayStr += $"{clickedBtn.Content}";
			internalStr += $"{clickedBtn.Content}";
			if((string)clickedBtn.Content == ".") { dotted = true; }
			// TODO: Data Binding not implemented! 
			EvaluateDisplay();
#if dotDebug
			ResultBox.Text = dotted.ToString();
#endif
#if parseDebug
			ResultBox.Text = internalStr;
#endif
#if disDebug
			ResultBox.Text = displayStr;
#endif
		}

		private void FunctionBtn_Click(object sender, RoutedEventArgs e)
		{
			int lastIndex = 0;
			string tmp = "";
			double junk = 0.0;
			switch (((Button)sender).Name)
			{
				case "BtnPlus":
					lastIndex = internalStr.Count<char>() - 1;
					if(lastIndex < 0) { internalStr += "+ "; break; }
					if(internalStr[lastIndex] == ' ')
					{
						if(internalStr[lastIndex - 1] == '-') { internalStr = internalStr.Remove(lastIndex - 1) + "+ "; }
						else if(internalStr[lastIndex - 1] == '+') { DottedEvaluate(); break; }
						else if(internalStr[lastIndex - 1] == ')') { internalStr += "+ "; }
						else
						{
							DottedEvaluate();
							break;
						}
					}
					else
					{
						if (internalStr[lastIndex] != '-')
						{
							internalStr += " + ";
						}
						else
						{
							internalStr = internalStr.Remove(lastIndex);
						}
					}
					break;
				case "BtnSubtract":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { internalStr += "- "; break; }
					if (internalStr[lastIndex] == ' ')
					{
						if (internalStr[lastIndex - 1] == '+') { internalStr = internalStr.Remove(lastIndex - 1) + "- "; }
						else if (internalStr[lastIndex - 1] == '-') { break; }
						else if (internalStr[lastIndex - 1] == ')') { internalStr += "+ "; }
						else
						{
							internalStr += " -";
						}
					}
					else
					{
						if (internalStr[lastIndex] != '-')
						{
							internalStr += " - ";
						}
						else
						{
							break;
						}
					}
					break;
				case "BtnMulti":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { break; }
					if (internalStr[lastIndex] == ' ')
					{
						if(internalStr[lastIndex - 1] == ')') { internalStr += " * "; }
						else if (internalStr[lastIndex - 1] == '+' ||
							internalStr[lastIndex - 1] == '-' ||
							internalStr[lastIndex - 1] == '/' ||
							internalStr[lastIndex - 1] == '^')
						{
							if (lastIndex < 2) { break; }
							internalStr = internalStr.Remove(lastIndex - 1) + "* ";
						}
						else
						{
							break;
						}
					}
					else
					{
						internalStr += " * ";
					}
					break;
				case "BtnDiv":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { break; }
					if (internalStr[lastIndex] == ' ')
					{
						if (internalStr[lastIndex - 1] == ')') { internalStr += " / "; }
						else if (internalStr[lastIndex - 1] == '+' ||
							internalStr[lastIndex - 1] == '-' ||
							internalStr[lastIndex - 1] == '*' ||
							internalStr[lastIndex - 1] == '^')
						{
							if (lastIndex < 2) {  break; }
							internalStr = internalStr.Remove(lastIndex - 1) + "/ ";
						}
						else
						{
							break;
						}
					}
					else
					{
						internalStr += " / ";
					}
					break;
				case "BtnPaL":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { break; }
					if (internalStr[lastIndex] == ' ')
					{
						if (internalStr[lastIndex - 1] == '(') { internalStr += " ( "; }
						else if (internalStr[lastIndex - 1] == '+' ||
							internalStr[lastIndex - 1] == '-' ||
							internalStr[lastIndex - 1] == '*' ||
							internalStr[lastIndex - 1] == '/' ||
							internalStr[lastIndex - 1] == '^') { internalStr += " ( "; }
						else
						{
							break;
						}
					}
					else
					{
						internalStr += " * ( ";
					}
					break;
				case "BtnPaR":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { internalStr += "( "; break; }
					if (internalStr[lastIndex] == ' ')
					{
						if (internalStr[lastIndex - 1] == ')') { internalStr += " ) "; }
						else if (internalStr[lastIndex - 1] == '+' ||
							internalStr[lastIndex - 1] == '-' ||
							internalStr[lastIndex - 1] == '*' ||
							internalStr[lastIndex - 1] == '/' ||
							internalStr[lastIndex - 1] == '^') { internalStr = internalStr.Remove(lastIndex - 1) + ") "; }
						//else
						//{
						//	break;
						//}
					}
					else
					{
						internalStr += " ) ";
					}
					break;
				case "BtnPow":
					lastIndex = internalStr.Count<char>() - 1;
					if (lastIndex < 0) { break; }
					if (internalStr[lastIndex] == ' ')
					{
						if (internalStr[lastIndex - 1] == ')') { internalStr += " ^ "; }
						else if (internalStr[lastIndex - 1] == '+' ||
							internalStr[lastIndex - 1] == '-' ||
							internalStr[lastIndex - 1] == '*') { internalStr = internalStr.Remove(lastIndex - 1) + "^ "; }
						else
						{
							break;
						}
					}
					else
					{
						internalStr += " ^ ";
					}
					break;
				case "BtnSqrt":
					tmp = internalStr.TrimEnd();
					if(tmp.Length == 0)
					{
						internalStr += " sqrt ( ";
						break;
					}
					junk = 0.0;
					if (double.TryParse(tmp[tmp.Length - 1].ToString(), out junk) == false)
					{
						internalStr += " sqrt ( ";
					}
					break;
				case "BtnLog":
				case "BtnLn":
				case "BtnSin":
				case "BtnCos":
				case "BtnTan":
					tmp = internalStr.TrimEnd();
					if (tmp.Length == 0)
					{
						internalStr += $" {((Button)sender).Content} ( ";
						break;
					}
					junk = 0.0;
					if (double.TryParse(tmp[tmp.Length - 1].ToString(), out junk) == false)
					{
						internalStr += $" {((Button)sender).Content} ( ";
					}
					break;
				default:
					throw new ArgumentException();
					//+-*/ log, ln, pow, sqrt, (), sin, cos, tan
			}
			DottedEvaluate();
			EvaluateDisplay();
#if parseDebug
			ResultBox.Text = internalStr;
#endif
#if disDebug
			ResultBox.Text = displayStr;
#endif
		}

		void FirstRun()
		{
			Btn1.Click += NumPadBtn_Click;
			Btn2.Click += NumPadBtn_Click;
			Btn3.Click += NumPadBtn_Click;
			Btn4.Click += NumPadBtn_Click;
			Btn5.Click += NumPadBtn_Click;
			Btn6.Click += NumPadBtn_Click;
			Btn7.Click += NumPadBtn_Click;
			Btn8.Click += NumPadBtn_Click;
			Btn9.Click += NumPadBtn_Click;
			Btn0.Click += NumPadBtn_Click;
			BtnDot.Click += NumPadBtn_Click;

			BtnPlus.Click += FunctionBtn_Click;
			BtnSubtract.Click += FunctionBtn_Click;
			BtnMulti.Click += FunctionBtn_Click;
			BtnDiv.Click += FunctionBtn_Click;

			BtnLog.Click += FunctionBtn_Click;
			BtnLn.Click += FunctionBtn_Click;
			BtnPow.Click += FunctionBtn_Click;
			BtnSqrt.Click += FunctionBtn_Click;
			BtnPaL.Click += FunctionBtn_Click;
			BtnPaR.Click += FunctionBtn_Click;
			BtnSin.Click += FunctionBtn_Click;
			BtnCos.Click += FunctionBtn_Click;
			BtnTan.Click += FunctionBtn_Click;

		}

		private void BtnClear_Click(object sender, RoutedEventArgs e)
		{
			internalStr = "";
			displayStr = "0";
			dotted = false;
			EvaluateDisplay();
#if disDebug
			ResultBox.Text = displayStr;
#endif
		}

		private void BtnEqual_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Arithmetics calculation = new Arithmetics(internalStr);
				displayStr = calculation.Evaluate().ToString();
			}
			catch (DivideByZeroException)
			{
				displayStr = resLoader.GetString("DivZeroMsg");
				//displayStr = "Cannot divide by zero";
			}
			catch (ArgumentOutOfRangeException)
			{
				displayStr = resLoader.GetString("InvalidArgsMsg");
				//displayStr = "Invalid argument";
			}
			catch (FormatException)
			{
				displayStr = resLoader.GetString("FormatErrMsg");
				//displayStr = "Input format error";
			}
			catch (IndexOutOfRangeException)
			{
				displayStr = resLoader.GetString("FormatErrMsg");
				//displayStr = "Input format error";
			}
#if parseDebug
			ResultBox.Text = displayStr;
#endif
#if disDebug
			CopyStore.DisplayStr = displayStr;
			ResultBox.Text = displayStr;
#endif
		}

		private void BtnBackSp_Click(object sender, RoutedEventArgs e)
		{
			int lastIndex = internalStr.Length - 1;
			if(lastIndex < 0) { return; }
			while(internalStr[lastIndex] == ' ')
			{
				internalStr = internalStr.Remove(lastIndex);
				lastIndex--;
			}
			if (internalStr[lastIndex] == '(')
			{
				internalStr = internalStr.Remove(lastIndex);
				lastIndex--;
				internalStr = internalStr.Remove(lastIndex);
				lastIndex--;

				if (internalStr[lastIndex] == 'n')
				{
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					if (internalStr[lastIndex] == 'l')
					{
						internalStr = internalStr.Remove(lastIndex);
						lastIndex--;
					}
					else
					{
						internalStr = internalStr.Remove(lastIndex);
						lastIndex--;
						internalStr = internalStr.Remove(lastIndex);
						lastIndex--;
					}
				}
				else if (internalStr[lastIndex] == 'g' || internalStr[lastIndex] == 's')
				{
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
				}
				else if(internalStr[lastIndex] == 't')
				{
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
					internalStr = internalStr.Remove(lastIndex);
					lastIndex--;
				}
			}
			else
			{
				internalStr = internalStr.Remove(lastIndex);
				lastIndex--;
			}
			if (internalStr.Length > 0 && internalStr[0] != ' ')
			{
				double junk = 0.0;
				if (double.TryParse(internalStr.TrimEnd().Last<char>().ToString(), out junk) == true)
				{
					internalStr = internalStr.TrimEnd();
				}
			}
			DottedEvaluate();
			EvaluateDisplay();
#if parseDebug
			ResultBox.Text = internalStr;
#endif
#if disDebug
			ResultBox.Text = displayStr;
#endif
		}

		void DottedEvaluate()
		{
			dotted = false;
			for(int i = internalStr.Length - 1; i >= 0; i--)
			{
				if(internalStr[i] == '.') { dotted = true; }
				if(internalStr[i] == ' ') { break; }
			}
#if dotDebug
			ResultBox.Text = dotted.ToString();
#endif
		}
		void EvaluateDisplay()
		{
			displayStr = "";
			if(internalStr == "")
			{
				displayStr = "0"; return;
			}
			foreach (char ch in internalStr)
			{
				if(ch != ' ')
				{
					if (ch == '*') { displayStr += '×'; }
					else if (ch == '/') { displayStr += '÷'; }
					else { displayStr += ch; }
				}
			}
			CopyStore.DisplayStr = displayStr;
		}

		private void BtnE_Click(object sender, RoutedEventArgs e)
		{
			bool newNum = true;
			double junk = 0.0;
			if (internalStr.Length - 1 > 0)
			{
				for (int i = internalStr.Length - 1; i >= 0; i--)
				{
					if (internalStr[i] == ' ' || internalStr[i] == '.') { continue; }
					else if (double.TryParse(internalStr[i].ToString(), out junk) == true) { newNum = false; }
					else { break; }
				}

				if (newNum == true)
				{
					if (internalStr[internalStr.Length - 1] == ' ') { internalStr += Math.E.ToString(); }
					else if (internalStr[internalStr.Length - 1] == '+' || internalStr[internalStr.Length - 1] == '-')
					{
						internalStr += Math.E.ToString();
					}
					else
					{
						internalStr += " " + Math.E.ToString();
					}
				}

			}
			else
			{
				internalStr += Math.E.ToString();
			}
			EvaluateDisplay();
#if disDebug
			ResultBox.Text = displayStr;
#endif

		}

		private void BtnPi_Click(object sender, RoutedEventArgs e)
		{
			bool newNum = true;
			double junk = 0.0;
			if (internalStr.Length - 1 > 0)
			{
				for (int i = internalStr.Length - 1; i >= 0; i--)
				{
					if (internalStr[i] == ' ' || internalStr[i] == '.') { continue; }
					else if (double.TryParse(internalStr[i].ToString(), out junk) == true) { newNum = false; }
					else { break; }
				}

				if (newNum == true)
				{
					if (internalStr[internalStr.Length - 1] == ' ') { internalStr += Math.PI.ToString(); }
					else if (internalStr[internalStr.Length - 1] == '+' || internalStr[internalStr.Length - 1] == '-')
					{
						internalStr += Math.PI.ToString();
					}
					else
					{
						internalStr += " " + Math.PI.ToString();
					}
				}

			}
			else
			{
				internalStr += Math.PI.ToString();
			}
			EvaluateDisplay();
#if disDebug
			ResultBox.Text = displayStr;
#endif

		}
	}
}
