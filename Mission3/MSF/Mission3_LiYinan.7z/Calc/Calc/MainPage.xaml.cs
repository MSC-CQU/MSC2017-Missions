﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.ViewManagement;
using Windows.ApplicationModel.Core;
using Windows.ApplicationModel.DataTransfer;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Calc
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
		{
			FirstRun();
		}

		private void FirstRun()
		{
			this.InitializeComponent();
			var titleBar = CoreApplication.GetCurrentView().TitleBar;
			titleBar.ExtendViewIntoTitleBar = true;
			ApplicationViewTitleBar title = ApplicationView.GetForCurrentView().TitleBar;
			title.ButtonBackgroundColor = Windows.UI.Colors.Transparent;
			//AppTitleBar.Height = titleBar.Height;
			//Window.Current.SetTitleBar(AppTitleBar);
			SolidColorBrush titleBtnStyle = (SolidColorBrush)Application.Current.Resources["AppBarItemForegroundThemeBrush"];
			title.ButtonForegroundColor = titleBtnStyle.Color;
			foreach (NavigationViewItemBase item in NavView.MenuItems)
			{
				if (item is NavigationViewItem && item.Tag.ToString() == "real")
				{
					NavView.SelectedItem = item;
					break;
				}
			}
			ContentFrame.Navigate(typeof(Real));
		}


		private void NavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
		{
			if ((args.SelectedItem as NavigationViewItem).Tag.ToString() == "real")
			{
				ContentFrame.Navigate(typeof(Real));
			}
			else
			{
				ContentFrame.Navigate(typeof(Cmplx));
			}
		}

		private void CopyBtn_Click(object sender, RoutedEventArgs e)
		{
			DataPackage dataPack = new DataPackage();
			dataPack.RequestedOperation = DataPackageOperation.Copy;
			dataPack.SetText($"{CopyStore.DisplayStr}");
			Clipboard.SetContent(dataPack);
		}

		//private void HistoryBtn_Click(object sender, RoutedEventArgs e)
		//{
		//	((StackPanel)(((Flyout)(((Button)sender).Flyout)).Content)).Children.Clear();

		//	for (int i = 0; i < HistoryStore.entries.Count; i++)
		//	{
		//		MenuFlyoutItem item = new MenuFlyoutItem();
		//		item.Text = $"{HistoryStore.entries[i].DisplayString}\n= {HistoryStore.entries[i].Result}";

		//		((StackPanel)(((Flyout)(((Button)sender).Flyout)).Content)).Children.Add(item);
		//	}
		//}
	}
}
