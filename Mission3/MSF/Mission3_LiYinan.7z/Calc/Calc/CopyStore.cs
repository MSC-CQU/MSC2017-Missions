﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
	public static class CopyStore
	{
		public static string DisplayStr { get; set; } = "0";
	}
}
