﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mission3
{
    /// <summary>
    /// ComplexPage.xaml 的交互逻辑
    /// </summary>
    /// 
    
    public partial class ComplexPage : Page
    {
        //用于和主窗体交互
        private MainWindow parentWindow
        {
            get { return parentWindow; }
            set { parentWindow = value; }
        }
        
        private ComplexCalcCore mon;

        public ComplexPage()
        {
            InitializeComponent();
            mon = new ComplexCalcCore(ComplexMonitor);
            
            //GetType().GetField("plus", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.IgnoreCase).GetValue(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button bt = (Button)sender;
            mon.input(bt.Content.ToString());
        }
    }
}
