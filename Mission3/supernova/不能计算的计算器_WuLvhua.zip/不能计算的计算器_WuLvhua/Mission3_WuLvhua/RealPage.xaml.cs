﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mission3
{
    /// <summary>
    /// RealPage.xaml 的交互逻辑
    /// </summary>
    public partial class RealPage : Page
    {

        private Label label;    //标签实例
        private RealCalcCore mon;    //文本输出管理

        public RealPage()
        {
            InitializeComponent();
            mon = new RealCalcCore(label);
            
            //GetType().GetField("plus", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.IgnoreCase).GetValue(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button bt = (Button)sender;
            mon.input(bt.Content.ToString());
        }

        private void Label_Initialized(object sender, EventArgs e)
        {
            label = (Label)sender;
        }

    }
}
