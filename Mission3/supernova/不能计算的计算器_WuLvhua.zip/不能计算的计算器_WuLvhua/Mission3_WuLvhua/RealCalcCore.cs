﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Mission3
{
    /**
     *     实数计算器的实现
     */
    public class RealCalcCore
    {
        private Label ComplexMonitor;        
        private Stack<RealElement> stack;
        Char sign = '+';
        String halfValue = "";


        public RealCalcCore(Label label)
        {
            this.ComplexMonitor = label;
        }


        public void input(String key)
        {
            // 得出是否为操作符
            Boolean isOperator = false;
            try
            {
                int.Parse(key);
            }
            catch (FormatException fe)
            {
                //抛出异常则键入非数字
                if (!key.Equals("."))    //小数点作为数字来看待
                    isOperator = true;
            }

            switch (key)
            {
                case "AC":
                    stack.Clear();
                    changeHalfValueAndPost("");
                    break;
                case "←":
                    //version1 ： ComplexMonitor.Content = ComplexMonitor.Content.ToString().Reverse().ToString().Substring(1).Reverse().ToString();

                    if (halfValue.Length > 0) changeHalfValueAndPost(halfValue.Substring(0, halfValue.Length - 1));
                    break;
                case "±":
                    sign = sign == '+' ? '-' : '+';
                    postDisply();
                    break;
                case "=":
                    break;
                default:    //数值 | 小数点 | 双目运算符 的操作。
                    if (isOperator)
                    {
                        //处于编辑状态中的数值非空 且 栈内最顶端值不是符号
                        //那么就保存处于编辑状态的数值 并且 提交符号
                        //To-do: halfValue是否是小数点结尾
                        if (!halfValue.Equals("") && !stack.First().isOpt)
                        {
                            stack.Push(new RealElement(Double.Parse(halfValue)));
                            stack.Push(new RealElement(Char.Parse(key)));
                        }
                    }
                    else
                    {
                        changeHalfValueAndPost(halfValue + key);
                    }

                    break;

            }




        }
        //当删除完halfValue中所有字符之后，从栈顶取出元素放入halfValue（符号直接删掉）
        private void backStackToHalfValue()
        {
            
        }

        private void changeHalfValueAndPost(String newHalf)
        {
            halfValue = newHalf;
            postDisply();
        }

        private void postDisply()
        {
            //需要重新改正 负数显示问题
            ComplexMonitor.Content = stack.ToArray().ToString() + sign + halfValue;
        }
    }
}
