﻿using Mission2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Mission3
{
    /**
     *      处理模式：  输入一串表达式  a + bi + c + d + (fi + g) * (h +ji) 
     *      关键点：    1.所有数字都标识为复数
     *                  2.同样使用contentList分析
     *                  3.分段方式 从左至右遍历 
     *                  4.输入表达式时维护好 表达式数据
     */

    class ComplexCalcCore
    {

        private Label ComplexMonitor;
        private List<ComplexElement> contentList;
        private static char[] OPTS = { '＋','-','×','÷', '∧','(',')'};
        String halfValue = "";


        public ComplexCalcCore(Label label)
        {
            this.ComplexMonitor = label;
            contentList = new List<ComplexElement>();
        }


        public void input(String key)
        {
            switch (key)
            {
                case "AC":
                    contentList.Clear();
                    clearHalfValue();
                    break;

                case "←":
                    // TODO ： 从contentList中删除内容
                    if (halfValue.Length > 0) changeHalfValueAndPost(halfValue.Substring(0, halfValue.Length - 1));
                    break;

                case "=":          // TODO 完成计算
                    Calculate();
                    break;

                    default:    //数值 | 小数点 | i | 加减乘除指数运算符 | 括号


                        /**     ==================数值==============================
                         *      数值        ：      加到halfvalue末尾
                         *      小数点      ：      加到halfvalue末尾
                         *      
                         *      ==================操作符============================
                         *      i           ：      halfvalue作为复数入contentList
                         *      ＋-×÷∧   ：      halfvalue作为实数入contentList ，符号入contentList
                         *      (           ：      halfvalue非空，无操作 
                         *                          halfvalue空，左括号作为符号入contentList
                         *      )           ：      halfvalue为空 无操作
                         *                          halfvalue非空 入contentList
                         * 
                         */

                        //判断是否为操作符
                        Boolean isOperator = false;
                        try
                        {
                            int.Parse(key);
                        }
                        catch (FormatException)
                        {
                            //抛出异常则键入非数字
                            if (!key.Equals("."))    //小数点作为数字来看待
                                isOperator = true;
                        }

                        if (isOperator)
                        {
                            //处于编辑状态中的数值非空 且 contentList内最顶端值不是符号
                            //那么就保存处于编辑状态的数值 并且 提交符号
                            //To-do: halfValue是否是小数点结尾

                            //TODO:　内容为空时不能输入符号 但是可以输入 ‘(’     尴尬）
                            if (!halfValue.Equals("") && contentList.Count>0 && !contentList.First().isOpt)
                            {
                                if (halfValue.Equals("i")){
                                    contentList.Add(new ComplexElement(new ComplexNumber(0,Double.Parse(halfValue))));
                                    clearHalfValue();
                                }
                                else  // 加减乘除 乘方 括号
                                {
                                    contentList.Add(new ComplexElement(new ComplexNumber(Double.Parse(halfValue))));
                                    contentList.Add(new ComplexElement(Char.Parse(key)));
                                    clearHalfValue();
                                }
                            }
                        }
                        else  //数值或小数点  TODO： 多小数点问题
                        {
                            changeHalfValue(halfValue + key);
                        }
                    break;
            }
            postDisply();
        }
        //当删除完halfValue中所有字符之后，从contentList顶取出元素放入halfValue（符号直接删掉）
        private void Calculator()
        {
            Stack<ComplexElement> stack = new Stack<ComplexElement>();
            foreach (ComplexElement ce in  contentList)
            {
                if (ce.isOpt)
                {
                    switch (ce.opt)
                    {
                        case '＋':
                            break;
                        case '-':
                            break;
                        case '×':
                            break;
                        case '÷':
                            break;
                        case '∧':
                            break;
                        case '（':
                            break;
                        case '）':
                            break;
                    }
                }
            }
        }

        private int getRank(char ch)
        {
            switch (ch)
            {
                case '＋':

                case '-':
                    return 1;

                case '×':

                case '÷':
                    return 2;
                case '∧':
                    return 3;
                default:
                    return 0;
            }
        }

        private void backStackToHalfValue()
        {

        }

        private void clearHalfValue()
        {
            halfValue = "";
        }

        private void changeHalfValueAndPost(String newHalf)
        {
            halfValue = newHalf;
            postDisply();
        }

        private void changeHalfValue(String newHalf)
        {
            halfValue = newHalf;
        }
        private void postDisply()
        {
            //需要重新改正 负数显示问题
            String content = "";
            for(int i = 0; i <  contentList.Count;i++){
                content += contentList[i].ToString();
            }
            ComplexMonitor.Content = content + halfValue;
        }
    }
}

