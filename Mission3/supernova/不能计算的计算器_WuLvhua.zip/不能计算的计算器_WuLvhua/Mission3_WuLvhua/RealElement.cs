﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mission3
{
    /**
    *      实数计算元
    *      可以是一个数值或者一个运算符
    */

    class RealElement
    {
        public Boolean isOpt;
        public double num;
        public Char opt;



        public RealElement(double num)
        {
            this.num = num;
            isOpt = false;
        }

        public RealElement(Char opt)
        {
            this.opt = opt;
            isOpt = false;
        }
    }
}
