﻿using Mission2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Mission3
{
    /**
     *      处理模式：  输入一串表达式  a + bi + c + d + (fi + g) * (h +ji) 
     *      关键点：    1.所有数字都标识为复数
     *                  2.同样使用contentList分析
     *                  3.分段方式 从左至右遍历 
     *                  4.输入表达式时维护好 表达式数据
     */

    class ComplexCalcCore
    {

        private Label ComplexMonitor;
        private static char NUM_TAG = 'n';
        //private static char[] OPTS = { '＋','-','×','÷', '∧','（',')'};
        String content = "";


        public ComplexCalcCore(Label label)
        {
            this.ComplexMonitor = label;
        }

        /**
         *      鬼知道愚蠢的用户会输入什么鬼东西，懒得去判断输入表达式的正确性了。。
         * 
         */
        public void input(String key)
        {
            switch (key)
            {
                case "AC":
                    ClearContent();
                    break;

                case "←":
                    // TODO ： 从contentList中删除内容
                    if (content.Length > 0) content = content.Substring(0, content.Length - 1);
                    break;

                case "=":          // TODO 完成计算
                    content = Calculate( getSufix());
                    break;

                default:
                    content += key;
                    break;
            }
            postDisply();
        }

        private String Calculate( String exp)
        {
            Stack<char> stack = new Stack<char>();
            ComplexNumber result = new ComplexNumber(0,0);
            foreach (char ch in stack)
            {
                if (ch >= '0' && ch <= '9')
                {
                    stack.Push(ch);
                }
                else if (ch == '.' || ch == 'i')
                {
                    stack.Push(ch);
                }
                else
                {
                    ComplexNumber complex1,complex2;
                    String tmp="";
                    while (stack.Peek()!=NUM_TAG)
                    {
                        tmp += stack.Pop();
                    }
                    stack.Pop();
                    complex1 = getComplex(tmp);
                    tmp = "";
                    while (stack.Peek() != NUM_TAG)
                    {
                        tmp += stack.Pop();
                    }
                    stack.Pop();
                    complex2 = getComplex(tmp);
                    switch (ch)
                    {
                        case '＋':
                            result = complex1 + complex2;
                            break;
                        case '-':
                            result = complex1 - complex2;
                            break;
                        case '×':
                            result = complex1 * complex2;
                            break;
                        case '÷':
                            result = complex1 / complex2;
                            break;
                        case '∧':
                            result = complex1 ^ (int)complex2.getReal();
                            break;
                    }
                }
            }
            return result.ToString();
        }

        private ComplexNumber getComplex(String s)
        {
            ComplexNumber complex;
            if (s.Contains('i'))
            {
                complex = new ComplexNumber(0, int.Parse(s));
            }
            else
            {
                complex = new ComplexNumber(int.Parse(s,0));
            }
            return complex;
        }

        private String getSufix()
        {
            Stack<char> stack = new Stack<char>();
            String output = "";
            foreach (char ch in  content)
            {
                if (ch == '（')
                {
                    output += ch;
                }else if (ch >= '0'&& ch <= '9' )
                {
                    output += ch;
                }else if (ch == '.'|| ch=='i')
                {
                    output += ch;
                }else if (ch == '）')
                {
                    stack.Push(NUM_TAG);
                    while (stack.Peek() != '（')
                    {
                        if (stack.Peek() != '（')
                        {
                            output += stack.Pop();
                        }
                        else
                        {
                            stack.Pop();
                        }
                    }
                }
                else
                {
                    stack.Push(NUM_TAG);
                    if (stack.Count == 0 || stack.Peek() == '（')
                    {
                        stack.Push(ch);
                    }
                    else if (getRank(stack.Peek()) >= getRank(ch))
                    {
                        while ( !(stack.Count == 0) || stack.Peek() == '（'|| getRank(stack.Peek())<getRank(ch))
                        {
                            output += stack.Pop();
                        }
                        stack.Push(ch);
                    }
                    else
                    {
                        stack.Push(ch);
                    }
                }

                while (!(stack.Count == 0))
                {
                    output += stack.Pop();
                }
            }
            return output;
        }

        private int getRank(char ch)
        {
            switch (ch)
            {
                case '＋':
                case '-':
                    return 1;
                case '×':
                case '÷':
                    return 2;
                case '∧':
                    return 3;
                default:    //数字 点 i NUM_TAG
                    return 0;
            }
        }

        private void ClearContent()
        {
            content = "";
        }
        
        private void postDisply()
        {
            //需要重新改正 负数显示问题
            ComplexMonitor.Content = content;
        }
    }
}

