﻿using Mission2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Mission3
{
    /**
     *      处理模式：  输入一串表达式  a + bi + c + d + (fi + g) * (h +ji) 
     *      关键点：    1.所有数字都标识为复数
     *                  2.同样使用栈分析
     *                  3.分段方式 从左至右遍历 
     */
    class ComplexCalcCore
    {

        private Label ComplexMonitor;
        private Stack<ComplexElement> stack;
        private static char[] OPTS = { '＋','-','×','÷', '∧','(',')'};
        String halfValue = "";


        public ComplexCalcCore(Label label)
        {
            this.ComplexMonitor = label;
            stack = new Stack<ComplexElement>();
        }


        public void input(String key)
        {
            switch (key)
            {
                case "AC":
                    stack.Clear();
                    clearHalfValue();
                    break;

                case "←":
                    // TODO ： 从栈中删除内容
                    if (halfValue.Length > 0) changeHalfValueAndPost(halfValue.Substring(0, halfValue.Length - 1));
                    break;

                case "=":          // TODO 完成计算
                    break;

                default:    //数值 | 小数点 | i | 加减乘除指数运算符 | 括号


                    /**     ==================数值==============================
                     *      数值        ：      加到halfvalue末尾
                     *      小数点      ：      加到halfvalue末尾
                     *      
                     *      ==================操作符============================
                     *      i           ：      halfvalue作为复数入栈
                     *      ＋-×÷∧   ：      halfvalue作为实数入栈 ，符号入栈
                     *      (           ：      halfvalue非空，无操作 
                     *                          halfvalue空，左括号作为符号入栈
                     *      )           ：      halfvalue为空 无操作
                     *                          halfvalue非空 入栈
                     * 
                     */

                    //判断是否为操作符
                    Boolean isOperator = false;
                    try
                    {
                        int.Parse(key);
                    }
                    catch (FormatException)
                    {
                        //抛出异常则键入非数字
                        if (!key.Equals("."))    //小数点作为数字来看待
                            isOperator = true;
                    }

                    if (isOperator)
                    {
                        //处于编辑状态中的数值非空 且 栈内最顶端值不是符号
                        //那么就保存处于编辑状态的数值 并且 提交符号
                        //To-do: halfValue是否是小数点结尾

                        //TODO:　内容为空时不能输入符号 但是可以输入 ‘(’     尴尬）
                        if (!halfValue.Equals("") && stack.Count>0 && !stack.First().isOpt)
                        {
                            if (halfValue.Equals("i")){
                                stack.Push(new ComplexElement(new ComplexNumber(0,Double.Parse(halfValue))));
                                clearHalfValue();
                            }
                            else  // 加减乘除 乘方 括号
                            {
                                stack.Push(new ComplexElement(new ComplexNumber(Double.Parse(halfValue))));
                                stack.Push(new ComplexElement(Char.Parse(key)));
                                clearHalfValue();
                            }
                        }
                    }
                    else  //数值或小数点  TODO： 多小数点问题
                    {
                        changeHalfValue(halfValue + key);
                    }
                    break;
            }
            postDisply();
        }
        //当删除完halfValue中所有字符之后，从栈顶取出元素放入halfValue（符号直接删掉）
        private void backStackToHalfValue()
        {

        }

        private void clearHalfValue()
        {
            halfValue = "";
        }

        private void changeHalfValueAndPost(String newHalf)
        {
            halfValue = newHalf;
            postDisply();
        }

        private void changeHalfValue(String newHalf)
        {
            halfValue = newHalf;
        }
        private void postDisply()
        {
            //需要重新改正 负数显示问题
            String content = "";
            foreach(ComplexElement ce in stack){
                content += ce.ToString();
            }
            ComplexMonitor.Content = content+ sign + halfValue;
        }
    }
}

