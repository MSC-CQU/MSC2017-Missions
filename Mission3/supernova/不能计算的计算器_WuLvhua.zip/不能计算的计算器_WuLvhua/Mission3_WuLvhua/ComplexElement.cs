﻿using Mission2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mission3
{
    class ComplexElement
    {
        public Boolean isOpt;
        public ComplexNumber num;
        public Char opt;
        
        public ComplexElement(ComplexNumber num)
        {
            this.num = num;
            isOpt = false;
        }

        public ComplexElement(Char opt)
        {
            this.opt = opt;
            isOpt = false;
        }

        public override String ToString()
        {
            if (isOpt)
            {
                return opt.ToString();
            }
            else
            {
                return num.ToString();
            }
        }
    }
}
