﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace Mission3 
{
    /**
     *      用于实现模糊效果，然而尚未实现 
     */
    class BlurMask : Grid
    {
        public BlurMask()
        {
            Border border = new Border();
            VisualBrush brush = new VisualBrush();
            //brush.Visual = targetPanel;
            brush.Stretch = Stretch.Uniform;
            border.Background = brush;
            border.Effect = new BlurEffect()
            {
                Radius = 80,
                RenderingBias = RenderingBias.Performance
            };
            border.Margin = new Thickness(-this.Margin.Left, -this.Margin.Top, 0, 0);
        }
    }
}
